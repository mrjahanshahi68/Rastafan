﻿using Rasta.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rasta.DataAccess.Employee
{
	public class EmployeeUnitOfWork : UnitOfWork<EmployeeDataContext>,IUnitOfWork
	{
	}
}

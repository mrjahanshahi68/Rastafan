﻿using Rasta.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rasta.DataAccess.Log
{
    public class LogUnitOfWork : UnitOfWork<LogDataContext>,IUnitOfWork
    {
    }
}

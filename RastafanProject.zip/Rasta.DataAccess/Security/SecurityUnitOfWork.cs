﻿using Rasta.DataAccess;
using Rasta.DataAccess.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rasta.DataAccess.Security
{
	public class SecurityUnitOfWork : UnitOfWork<SecurityDataContext>,IUnitOfWork
	{
	}
}

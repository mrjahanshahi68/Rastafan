﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace Rasta.Web.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            //ScriptBundle scriptBundle = new ScriptBundle("~/bundles");
            //bundles.Add(new ScriptBundle())
        }
    }
}